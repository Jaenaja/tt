<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('lottery_bets', function (Blueprint $table) {
            $table->id();

            // ข้อมูลงวด + ลูกค้า
            $table->date('draw_date');
            $table->string('customer_name');

            // เลขที่แทง (2 ตัว / 3 ตัว)
            $table->string('number', 3);

            // จำนวนเงินที่แทง
            $table->decimal('amount_top', 10, 2)->default(0);
            $table->decimal('amount_bottom', 10, 2)->default(0);
            $table->decimal('amount_toad', 10, 2)->default(0);

            // เงินรางวัล
            $table->decimal('payout_top', 10, 2)->default(0);
            $table->decimal('payout_bottom', 10, 2)->default(0);
            $table->decimal('payout_toad', 10, 2)->default(0);

            // สถานะถูกรางวัล
            $table->boolean('is_win_top')->default(false);
            $table->boolean('is_win_bottom')->default(false);
            $table->boolean('is_win_toad')->default(false);

            // เก็บเป็นตัวเลขธรรมดา ไม่ผูก FK
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();

            $table->softDeletes();
            $table->timestamps();

            // index ที่จำเป็น
            $table->index(['draw_date', 'customer_name']);
            $table->index('number');
        });
    }

    public function down()
    {
        Schema::dropIfExists('lottery_bets');
    }
};
