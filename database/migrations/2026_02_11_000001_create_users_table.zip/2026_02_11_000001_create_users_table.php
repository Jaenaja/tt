<?php
// database/migrations/2026_02_11_000001_create_users_table.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('username')->unique();
            $table->string('password');
            $table->enum('role', ['admin', 'general'])->default('general');
            $table->boolean('is_active')->default(true);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('users');
    }
};

// database/migrations/2024_01_01_000002_create_configs_table.php
return new class extends Migration
{
    public function up()
    {
        Schema::create('configs', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->string('value');
            $table->string('description')->nullable();
            $table->timestamps();
        });

        // Insert default rates
        DB::table('configs')->insert([
            ['key' => 'rate_2_top', 'value' => '90', 'description' => '2 ตัวบน'],
            ['key' => 'rate_2_bottom', 'value' => '90', 'description' => '2 ตัวล่าง'],
            ['key' => 'rate_3_top', 'value' => '900', 'description' => '3 ตัวบน'],
            ['key' => 'rate_3_toad', 'value' => '120', 'description' => '3 ตัวโต๊ด'],
        ]);
    }

    public function down()
    {
        Schema::dropIfExists('configs');
    }
};

// database/migrations/2024_01_01_000003_create_lottery_draws_table.php
return new class extends Migration
{
    public function up()
    {
        Schema::create('lottery_draws', function (Blueprint $table) {
            $table->id();
            $table->date('draw_date')->unique();
            $table->string('result_3_top', 3)->nullable(); // 3 ตัวบน
            $table->string('result_2_top', 2)->nullable(); // 2 ตัวบน
            $table->string('result_2_bottom', 2)->nullable(); // 2 ตัวล่าง
            $table->boolean('is_announced')->default(false);
            $table->timestamp('announced_at')->nullable();
            $table->foreignId('announced_by')->nullable()->constrained('users');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('lottery_draws');
    }
};

// database/migrations/2024_01_01_000004_create_lottery_bets_table.php
return new class extends Migration
{
    public function up()
    {
        Schema::create('lottery_bets', function (Blueprint $table) {
            $table->id();
            $table->date('draw_date');
            $table->string('customer_name');
            $table->string('number'); // เลขที่แทง
            $table->decimal('amount_top', 10, 2)->default(0); // บน
            $table->decimal('amount_bottom', 10, 2)->default(0); // ล่าง
            $table->decimal('amount_toad', 10, 2)->default(0); // โต๊ด
            $table->decimal('payout_top', 10, 2)->default(0); // เงินที่ได้จากบน
            $table->decimal('payout_bottom', 10, 2)->default(0); // เงินที่ได้จากล่าง
            $table->decimal('payout_toad', 10, 2)->default(0); // เงินที่ได้จากโต๊ด
            $table->boolean('is_win_top')->default(false);
            $table->boolean('is_win_bottom')->default(false);
            $table->boolean('is_win_toad')->default(false);
            $table->foreignId('created_by')->constrained('users');
            $table->foreignId('deleted_by')->nullable()->constrained('users');
            $table->timestamp('deleted_at')->nullable();
            $table->timestamps();

            $table->index(['draw_date', 'customer_name']);
            $table->index('created_by');
        });
    }

    public function down()
    {
        Schema::dropIfExists('lottery_bets');
    }
};